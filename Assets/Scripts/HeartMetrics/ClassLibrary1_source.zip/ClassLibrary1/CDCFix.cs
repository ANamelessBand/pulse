﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

using System.IO.Ports;

class CDCFix : SerialPort
{
    

    public bool Open(string num)
    {
        PortName = "COM" + num;
        ReadTimeout = 500;
        WriteTimeout = 500;
        try {
			Open();
		}
		catch {
			return false;
		}
		return IsOpen;
	}

    public int Get(String addr)
    {
		WriteLine( String.Format( "{0} ?", addr ) );
		return Int32.Parse(ReadLine(), NumberStyles.HexNumber);
	}

    public int Get(int addr)
    {
        WriteLine(String.Format("{0:x2} ?", addr));
        return Int32.Parse(ReadLine(), NumberStyles.HexNumber);
    }

    /*  Set value to SFR					*/
    public void Set(String addr, int data)
    {
        WriteLine(String.Format("{0:x2} {1} =", data & 0xff, addr));
		ReadLine();
	}

    public void Set(int addr, int data)
    {
        WriteLine(String.Format("{0:x2} {0:x2} =", data & 0xff, addr));
        ReadLine();
    }
}
