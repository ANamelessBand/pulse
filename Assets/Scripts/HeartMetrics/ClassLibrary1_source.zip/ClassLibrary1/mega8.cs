﻿using System;
using System.Collections.Generic;
using System.Text;

public enum M8
{
    DDRB = 0x37,
    PORTB = 0x38,
    DDRC = 0x34,
    PORTC = 0x35,
    ADCL = 0x24,
    ADCH = 0x25,
    ADCSRA = 0x26,
    ADMUX = 0x27
}
